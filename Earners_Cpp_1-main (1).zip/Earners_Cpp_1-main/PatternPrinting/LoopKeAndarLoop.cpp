#include<iostream>
using namespace std;
int main(){
    for(int k=1;k<=2;k++){
        for(int i=1;i<=4;i++){
            for(int j=1;j<=3;j++){
                cout<<"Good Morning"<<endl;
            }
        }
    }
}