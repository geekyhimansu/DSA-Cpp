#include<iostream>
using namespace std;
int main(){
    int t = 4;
    while(--t){
        cout<<"Hello"<<endl;
    }
}